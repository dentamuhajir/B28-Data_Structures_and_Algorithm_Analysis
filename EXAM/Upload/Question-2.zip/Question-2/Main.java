class SinglyNode {
    int data;             
    SinglyNode next;      

    // Constructor node, setiap node simpan data dan pointer ke node berikutnya
    SinglyNode(int data) {
        this.data = data;  
    }
}

/**
 * Class Process ini berfungsi untuk handle operasi Single Linked List
 * Mulai dari tambah data sampai menampilkan isi node
 */
class Process{
    SinglyNode head; // pointer awal linked list

    // Method add -> buat node baru, lalu taruh di bagian akhir list
    void add(int data) {
        SinglyNode newNode = new SinglyNode(data);  

        if (head == null) {     // kalau list masih kosong, node baru jadi head
            head = newNode;
            return;
        }

        SinglyNode current = head; 
        while (current.next != null) { // cari sampai node terakhir
            current = current.next;
        }
        current.next = newNode; // sambungkan node baru di paling belakang
    }
 
    // Method printData -> tampilkan isi linked list dengan format index dan data
    void printData() {
        SinglyNode current = head;
        System.out.println("Index | Data");
        System.out.println("--------------");
        int index = 0;
        while (current != null) {
            System.out.println(index + "     | " + current.data);
            index++;
            current = current.next; // lanjut ke node berikutnya
        }
    }

    // Method insertAfter -> sisipkan node baru setelah node dengan nilai tertentu
    void insertAfter(int target, int newData) {
        SinglyNode current = head;

        // Cari node sampai ketemu data yang sama dengan target
        while (current != null && current.data != target) {
            current = current.next;
        }

        // Kalau node target tidak ada di list
        if (current == null) {
            System.out.println("Node dengan nilai " + target + " tidak ditemukan.");
            return;
        }

        // Buat node baru dan hubungkan: newNode -> node setelah current
        SinglyNode newNode = new SinglyNode(newData);
        newNode.next = current.next;

        // Hubungkan current -> newNode, sehingga newNode masuk setelah target
        current.next = newNode;

        System.out.println("Insert angka " + newData + " setelah angka " + target);
    }

    void delete(int target) {
        // cek dulu kalau list masih kosong, tidak ada yang bisa dihapus
        if (head == null) {
            System.out.println("List kosong, tidak ada yang dihapus.");
            return;
        }

        // kalau data yang mau dihapus ada di node pertama (head)
        if (head.data == target) {
            head = head.next; // geser head ke node berikutnya
            System.out.println("Node dengan nilai " + target + " dihapus.");
            return;
        }

        // mulai cari node sebelum target
        SinglyNode current = head;
        while (current.next != null && current.next.data != target) {
            current = current.next; // geser maju sampai ketemu target atau habis
        }

        // kalau sudah sampai akhir dan target tidak ketemu
        if (current.next == null) {
            System.out.println("Node dengan nilai " + target + " tidak ditemukan.");
            return;
        }

        // kalau ketemu, lewatin node target (hapus node-nya)
        current.next = current.next.next;
        System.out.println("Node dengan nilai " + target + " dihapus.");
    }

}

/**
 * Class Main 
 * Di sini kita isi linked list dengan array data, lalu panggil printData untuk menampilkan
 */
public class Main {
    public static void main(String[] args) {
        Process singleLinkedList = new Process();
        int[] data = {43, 5, 9, 42, 6, 11, 41, 7, 13, 100, 12, 70, 24, 40, 36, 16, 35, 14, 30, 25}; 
      
        System.out.println("Insert semua angka ke Single Linked List");
        for(int number: data) {
            singleLinkedList.add(number);    // tambahkan tiap angka ke linked list
        }

        singleLinkedList.printData();

        // Sisipkan angka 60 setelah node dengan nilai 24
        // Jadi urutannya: ... 24 -> 60 -> 40 ...
        singleLinkedList.insertAfter(24, 60);
        singleLinkedList.printData();

        // Hapus angka 35 dari list
        singleLinkedList.delete(35);
        singleLinkedList.printData();
    }
}
