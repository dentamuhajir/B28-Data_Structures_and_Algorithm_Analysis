import java.util.*;

public class Main {

    // Node class merepresentasikan setiap elemen di dalam BST
    static class Node {
        int key;          // value dari node
        Node left, right; // pointer ke left child dan right child

        Node(int key) { 
            this.key = key; 
        }
    }

    // Binary Search Tree (BST) implementation
    static class BST {
        private Node root; // root dari tree

        // Public method untuk insert data baru ke BST
        public void insert(int key) {
            root = insertRec(root, key);
        }

        // Recursive method untuk proses insert
        private Node insertRec(Node node, int key) {
            // jika node kosong -> buat node baru
            if (node == null) return new Node(key);

            // rule BST: value < root -> masuk left subtree
            if (key < node.key) node.left = insertRec(node.left, key);
            // rule BST: value > root -> masuk right subtree
            else if (key > node.key) node.right = insertRec(node.right, key);

            // kembalikan node (update tree)
            return node;
        }

        // Mengecek apakah key ada di BST
        public boolean contains(int key) {
            return containsRec(root, key);
        }

        private boolean containsRec(Node node, int key) {
            if (node == null) return false;          // tidak ditemukan
            if (key == node.key) return true;        // ketemu
            // recursive ke kiri atau kanan sesuai rule BST
            return key < node.key ? containsRec(node.left, key) : containsRec(node.right, key);
        }

        // Inorder traversal (Left - Root - Right)
        public List<Integer> inorder() {
            List<Integer> res = new ArrayList<>();
            inorderRec(root, res);
            return res;
        }
        private void inorderRec(Node node, List<Integer> res) {
            if (node == null) return;
            inorderRec(node.left, res);  // left subtree
            res.add(node.key);           // visit node
            inorderRec(node.right, res); // right subtree
        }

        // Preorder traversal (Root - Left - Right)
        public List<Integer> preorder() {
            List<Integer> res = new ArrayList<>();
            preorderRec(root, res);
            return res;
        }
        private void preorderRec(Node node, List<Integer> res) {
            if (node == null) return;
            res.add(node.key);            // visit node
            preorderRec(node.left, res);  // left subtree
            preorderRec(node.right, res); // right subtree
        }

        // Postorder traversal (Left - Right - Root)
        public List<Integer> postorder() {
            List<Integer> res = new ArrayList<>();
            postorderRec(root, res);
            return res;
        }
        private void postorderRec(Node node, List<Integer> res) {
            if (node == null) return;
            postorderRec(node.left, res);  // traverse left
            postorderRec(node.right, res); // traverse right
            res.add(node.key);             // visit node terakhir
        }

        // Method untuk print tree dalam bentuk visual sideways
        public void printTree() {
            if (root == null) {
                System.out.println("(empty)");
                return;
            }
            printTreeRec(root, "", true);
        }

        // Recursive helper untuk print struktur tree sideways
        private void printTreeRec(Node node, String prefix, boolean isTail) {
            if (node.right != null) {
                printTreeRec(node.right, prefix + (isTail ? "│   " : "    "), false);
            }
            System.out.println(prefix + (isTail ? "└── " : "┌── ") + node.key);
            if (node.left != null) {
                printTreeRec(node.left, prefix + (isTail ? "    " : "│   "), true);
            }
        }
    }

    public static void main(String[] args) {
        // Dataset dari soal
        int[] data = {10, 15, 21, 17, 19, 9, 23, 29, 4, 13};
        BST bst = new BST();

        // Insert semua data ke BST sesuai urutan
        for (int x : data) {
            bst.insert(x);
        }

        // Print struktur tree (sideways)
        System.out.println("Struktur BST (sideways):");
        bst.printTree();

        // Print traversal results
        System.out.println("\nInorder   (sorted):   " + bst.inorder());   // hasil sorted
        System.out.println("Preorder  (root,LR):  " + bst.preorder());  // root-first
        System.out.println("Postorder (LR,root):  " + bst.postorder()); // root-lastb
    }
}
