// Node untuk Doubly Linked List
class DoublyNode {
    int data;           // simpan nilai data
    DoublyNode next;    // pointer ke node berikutnya
    DoublyNode prev;    // pointer ke node sebelumnya

    DoublyNode(int data) {
        this.data = data;
    }
}

// Struktur Doubly Linked List
class DoublyLinkedList {
    DoublyNode head; // pointer awal list
    DoublyNode tail; // pointer akhir list

    // tambah node di akhir
    void add(int data) {
        DoublyNode newNode = new DoublyNode(data);

        if (head == null) { // kalau list masih kosong
            head = newNode;
            tail = newNode;
            return;
        }

        tail.next = newNode; // hubungkan tail lama ke node baru
        newNode.prev = tail; // node baru menunjuk balik ke tail lama
        tail = newNode;      // update tail ke node baru
    }

    // tambah banyak data sekaligus
    void addAll(int[] data) {
        for (int number : data) {
            add(number);
        }
    }

    // cetak dari depan ke belakang
    void printForward() {
        DoublyNode current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }

    
    // sisipkan data baru setelah target tertentu
    void insertAfter(int target, int newData) {
        DoublyNode current = head;

        // cari node dengan nilai = target
        while (current != null && current.data != target) {
            current = current.next;
        }

        if (current == null) { // kalau tidak ketemu
            System.out.println("Node dengan nilai " + target + " tidak ditemukan.");
            return;
        }

        DoublyNode newNode = new DoublyNode(newData);
        newNode.next = current.next; // node baru menunjuk ke node setelah target
        newNode.prev = current;      // node baru menunjuk balik ke target

        if (current.next != null) {  
            current.next.prev = newNode; // kalau bukan tail, update prev node setelah target
        } else {
            tail = newNode; // kalau target adalah tail, node baru jadi tail
        }

        current.next = newNode; // hubungkan target ke node baru
    }

    
    // hapus node dengan nilai tertentu
    void delete(int target) {
        if (head == null) { // kalau list kosong
            System.out.println("List kosong, tidak ada yang dihapus.");
            return;
        }

        DoublyNode current = head;

        // cari node dengan nilai = target
        while (current != null && current.data != target) {
            current = current.next;
        }

        if (current == null) { // kalau tidak ketemu
            System.out.println("Node dengan nilai " + target + " tidak ditemukan.");
            return;
        }

        if (current.prev != null) {
            current.prev.next = current.next; // lewati node current
        } else {
            head = current.next; // kalau node dihapus adalah head
        }

        if (current.next != null) {
            current.next.prev = current.prev; // hubungkan node setelahnya ke prev
        } else {
            tail = current.prev; // kalau node dihapus adalah tail
        }

    }

}

public class Main {
    public static void main(String[] args) {
        DoublyLinkedList dll = new DoublyLinkedList();

        int[] data = {77, 208, 94, 46, 39, 92, 117, 52, 60, 104, 184, 351}; 

        // insert semua angka ke DLL
        dll.addAll(data);
        System.out.println("Sebelum operasi:");
        dll.printForward();       

        // insert angka 13 setelah angka 60
        dll.insertAfter(60, 13);
        System.out.println("\nSetelah insert anka 13 setelah angka 60:");
        dll.printForward();

        // delete angka 46
        dll.delete(46);
        System.out.println("\nSetelah delete angka 46:");
        dll.printForward();
    }
}