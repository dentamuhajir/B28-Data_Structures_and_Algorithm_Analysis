class Vehicle {
    private String type;
    private String merch;
    private int year;

    public Vehicle(String type, String merch, int  year) {
        this.type = type;
        this.merch = merch;
        this.year = year;
    }

    // Getter untuk modifikasi private property
    public String getType() {
        return type;
    }
    
    public String getMerch() {
        return merch;
    }

    public int  getYear() {
        return year;
    }
    
    // Implementasi default yang akan override oleh child class 
    public void vehicleInformation() {
        System.out.println(getType() + " : " + getMerch() + " | tahun " + getYear() + "");
    }
    
}

class Car extends Vehicle {
    // Konstanta TYPE
    private static final String TYPE = "Mobil";
    private int chair;

    public Car(String merch, int year, int chair) {
        super(TYPE, merch, year);
        this.chair = chair;
    }

    // Override method dari parent (polymorphism)
    @Override
    public void vehicleInformation() {
        System.out.println(getType() + " : " + getMerch() + 
                           " | tahun " + getYear() + 
                           " | jumlah kursi: " + chair);
    }
           
}

class Motorcycle extends Vehicle {
    private static final String TYPE = "Motor";
    private Boolean isSidecar; 

    public Motorcycle(String merch, int year, Boolean isSidecar) {
        super(TYPE, merch, year);
        this.isSidecar = isSidecar;
    }

    @Override
    public void vehicleInformation() {
        System.out.println(getType() + " : " + getMerch() + 
                           " | tahun " + getYear() + 
                           " | " + (isSidecar ? "Ada" : "Tanpa") + " sidecar");
    }
}

public class Main {
    public static void main(String[] args) {

        // Init Objek dari sebuah class
        Vehicle car = new Car("Toyota", 2020, 5);
        // Akses mthod dari sebuah class
        car.vehicleInformation();
        
        Vehicle motorcycle = new Motorcycle("Honda", 1995, false);
        motorcycle.vehicleInformation();
        
    }
}
